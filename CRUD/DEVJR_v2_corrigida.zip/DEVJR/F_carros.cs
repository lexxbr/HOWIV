﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DEVJR
{
    public partial class F_carros : Form
    {
        public F_carros()
        {
            InitializeComponent();
        }

        private MySqlConnectionStringBuilder ConexaoBanco()
        {
            MySqlConnectionStringBuilder conexaoBD = new MySqlConnectionStringBuilder();
            conexaoBD.Server = "localhost";
            conexaoBD.Database = "devjr";
            conexaoBD.UserID = "root";
            conexaoBD.Password = "";
            conexaoBD.SslMode = MySql.Data.MySqlClient.MySqlSslMode.None;
            return (MySqlConnectionStringBuilder)conexaoBD;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void lbl_descmar_Click(object sender, EventArgs e)
        {

        }

        private void tb_V_desc_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bt_Sair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tbVeiculos_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void bt_C_lista_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open();

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand();
                comandoMySql.CommandText = "SELECT * FROM veiculo WHERE car_id = '" + tb_V_cod.Text + "'";
                MySqlDataReader reader = comandoMySql.ExecuteReader();

                //dgLocadora.Rows.Clear();

                while (reader.Read())
                {
                    tb_V_cod.Text = reader.GetString(0);    //id
                    tb_V_desc.Text = reader.GetString(1);   // Descrição
                    tb_V_codmod.Text = reader.GetString(2); //modelo codigo
                    tb_V_ano.Text = reader.GetString(3);    //ano
                    cb_V_cor.Text = reader.GetString(4);    //cor
                    tb_V_obs.Text = reader.GetString(5);    //observação
                    car_apto.Text = reader.GetString(6);    //veiculo apto
                }

                realizaConexacoBD.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! ");
                Console.WriteLine(ex.Message);
            }
        }

        private void bt_C_altera_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open(); //Abre a conexão com o banco
                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand(); //Crio um comando SQL

                comandoMySql.CommandText = "UPDATE veiculo SET car_mod = '" + tb_V_codmod.Text + "', " +
                    "car_ano = '" + tb_V_ano.Text + "', " +
                    "car_cor = '" + cb_V_cor.Text + "', " +
                    "car_desc = '" + tb_V_desc.Text + "', " +
                    "car_obs = '" + tb_V_obs.Text + "', " +
                    "car_apto = '" + car_apto.Text + "' " +
                    " WHERE car_id = '" + tb_V_cod.Text + "'";
                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close(); // Fecho a conexão com o banco
                MessageBox.Show("Dados Atualizado com Sucesso!"); //Exibo mensagem de aviso
                AtualizaGrid();
                LimparCamposV();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            LimparCamposV();
        }
        private void LimparCamposV()
        {
            tb_V_cod.Clear();            //id
            tb_V_ano.Clear();            //ano
            tb_V_codmod.Clear();         //id modelo
            cb_V_cor.SelectedIndex = -1; //cor
            tb_V_desc.Clear();           //descrição
            tb_V_obs.Clear();            //obserevação
            dtg_V.ClearSelection();      //Grid
            car_apto.SelectedIndex = -1;  //Check list box apto
        }

        private void Dtg_V_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dtg_V.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                dtg_V.CurrentRow.Selected = true;
                //preenche os textbox com as células da linha selecionada
                tb_V_cod.Text = dtg_V.Rows[e.RowIndex].Cells["colVcod"].FormattedValue.ToString();
                tb_V_desc.Text = dtg_V.Rows[e.RowIndex].Cells["colVdesc"].FormattedValue.ToString();
                tb_V_codmod.Text = dtg_V.Rows[e.RowIndex].Cells["colVmod"].FormattedValue.ToString();
                tb_V_ano.Text = dtg_V.Rows[e.RowIndex].Cells["colVano"].FormattedValue.ToString();
                cb_V_cor.Text = dtg_V.Rows[e.RowIndex].Cells["colVcor"].FormattedValue.ToString();
                tb_V_obs.Text = dtg_V.Rows[e.RowIndex].Cells["colVobs"].FormattedValue.ToString();   //observação
                car_apto.Text = dtg_V.Rows[e.RowIndex].Cells["colVapto"].FormattedValue.ToString();    //veiculo apto
            }
        }

        private void Bt_C_cad_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open();

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand();

                //INSERT INTO `cliente` (`id`, `cli_cpf`, `cli_nome`, `cli_end`, `cli_bairro`, `cli_cep`, `cli_cidade`, `cli_uf`, `cli_email`, `cli_fone_w`)
                //VALUES(NULL, 'LIMPEZA', 'SABAO EM PÓ', '5', '7', '1');

                comandoMySql.CommandText = "INSERT INTO veiculo (car_mod, car_ano, car_cor, car_desc, car_obs, car_apto)" +
                        "VALUES('" + tb_V_ano.Text + "', '" + tb_V_codmod.Text + "', '" + cb_V_cor.Text + "', '" + tb_V_desc.Text + "', '" + tb_V_obs.Text + "', '" + car_apto.Text + "')";
                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close();
                MessageBox.Show("Veículo Cadastrado com Sucesso!");
                AtualizaGrid();
                LimparCamposV();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void P_Carros_Paint(object sender, PaintEventArgs e)
        {

        }

        private void F_carros_Load(object sender, EventArgs e)
        {
            AtualizaGrid();
            AtualizaGridMod();
            AtualizaGridMar();
        }
        private void AtualizaGrid()
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open();

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand();
                comandoMySql.CommandText = "SELECT * FROM veiculo WHERE car_apto = 'APTO'";
                MySqlDataReader reader = comandoMySql.ExecuteReader();

                dtg_V.Rows.Clear();

                while (reader.Read())
                {
                    DataGridViewRow row = (DataGridViewRow)dtg_V.Rows[0].Clone();//FAZ UM CAST E CLONA A LINHA DA TABELA
                    row.Cells[0].Value = reader.GetInt32(0);    //ID
                    row.Cells[1].Value = reader.GetString(1);   //DESCRICAO
                    row.Cells[2].Value = reader.GetString(2);   //ANO
                    row.Cells[3].Value = reader.GetString(3);   //MODELO CODIGO
                    row.Cells[4].Value = reader.GetString(4);   //COR
                    row.Cells[5].Value = reader.GetString(5);   //OBS
                    row.Cells[6].Value = reader.GetString(6);   //ATIVO

                    dtg_V.Rows.Add(row);                        //ADICIONO A LINHA NA TABELA
                }

                realizaConexacoBD.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sem conexão com o banco! veículo");
                Console.WriteLine(ex.Message);
            }
        }

        private void AtualizaGridMod()
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open();

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand();
                comandoMySql.CommandText = "SELECT * FROM modelo WHERE mod_ativo = 'ATIVO'";
                MySqlDataReader reader = comandoMySql.ExecuteReader();

                dtg_Mod.Rows.Clear();

                while (reader.Read())
                {
                    DataGridViewRow row = (DataGridViewRow)dtg_Mod.Rows[0].Clone();//FAZ UM CAST E CLONA A LINHA DA TABELA
                    row.Cells[0].Value = reader.GetInt32(0);    //ID
                    row.Cells[1].Value = reader.GetString(1);   //DESCRICAO
                    row.Cells[2].Value = reader.GetString(2);   //ANO
                    row.Cells[3].Value = reader.GetString(3);   //ATIVO

                    dtg_Mod.Rows.Add(row);                        //ADICIONO A LINHA NA TABELA
                }

                realizaConexacoBD.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sem conexão com o banco! Modelo");
                Console.WriteLine(ex.Message);
            }
        }

        private void AtualizaGridMar()
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open();

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand();
                comandoMySql.CommandText = "SELECT * FROM marca WHERE mar_ativo = 'ATIVO'";
                MySqlDataReader reader = comandoMySql.ExecuteReader();

                dtg_CM.Rows.Clear();

                while (reader.Read())
                {
                    DataGridViewRow row = (DataGridViewRow)dtg_CM.Rows[0].Clone();//FAZ UM CAST E CLONA A LINHA DA TABELA
                    row.Cells[0].Value = reader.GetInt32(0);    //ID
                    row.Cells[1].Value = reader.GetString(1);   //DESCRICAO
                    row.Cells[2].Value = reader.GetString(2);   //ATIVO
                    //row.Cells[2].Value = reader.GetString(2);   //ANO

                    dtg_CM.Rows.Add(row);                        //ADICIONO A LINHA NA TABELA
                }

                realizaConexacoBD.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sem conexão com o banco! Marca");
                Console.WriteLine(ex.Message);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click_1(object sender, EventArgs e)
        {

        }

        private void BtExcluir_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open(); //Abre a conexão com o banco

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand(); //Crio um comando SQL
                                                                               // "DELETE FROM filme WHERE idFilme = "+ textBoxId.Text +""
                                                                               //comandoMySql.CommandText = "DELETE FROM filme WHERE idFilme = " + tbID.Text + "";
                comandoMySql.CommandText = "DELETE from veiculo WHERE veiculo.car_id = " + tb_V_cod.Text + "";

                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close(); // Fecho a conexão com o banco
                MessageBox.Show("Veículo Deletado com Sucesso!"); //Exibo mensagem de aviso
                AtualizaGrid();                                                  //AtualizaGrid();
                LimparCamposV();
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Não foi possivel abrir a conexão! ");
                Console.WriteLine(ex.Message);
            }
        }

        private void tb_Veiculos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            LimparCamposM();
        }
        private void LimparCamposM()
        {
            tb_M_cod.Clear();
            tb_M_marca.Clear();
            tb_M_desc.Clear();
            cbx_M_apto.SelectedIndex = -1;
        }

        private void Dtg_Mod_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dtg_Mod.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                dtg_Mod.CurrentRow.Selected = true;
                //preenche os textbox com as células da linha selecionada
                tb_M_cod.Text = dtg_Mod.Rows[e.RowIndex].Cells["colMDcod"].FormattedValue.ToString();
                tb_M_marca.Text = dtg_Mod.Rows[e.RowIndex].Cells["colMDmar"].FormattedValue.ToString();
                tb_M_desc.Text = dtg_Mod.Rows[e.RowIndex].Cells["colMDdesc"].FormattedValue.ToString();
                cbx_M_apto.Text = dtg_Mod.Rows[e.RowIndex].Cells["colMDativo"].FormattedValue.ToString();
            }
        }

        private void bt_M_Listar_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open();

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand();
                comandoMySql.CommandText = "SELECT * FROM modelo WHERE mod_id = '" + tb_M_cod.Text + "'";
                MySqlDataReader reader = comandoMySql.ExecuteReader();

                //dgLocadora.Rows.Clear();

                while (reader.Read())
                {
                    tb_M_cod.Text = reader.GetString(0);     // Modelo id
                    tb_M_marca.Text = reader.GetString(1);   // Modelo cod
                    tb_M_desc.Text = reader.GetString(2);    // Modelo descrição
                    cbx_M_apto.Text = reader.GetString(3);    // Modelo descrição

                }

                realizaConexacoBD.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! ");
                Console.WriteLine(ex.Message);
            }
        }

        private void bt_M_cadastrar_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open();

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand();

                //INSERT INTO `cliente` (`id`, `cli_cpf`, `cli_nome`, `cli_end`, `cli_bairro`, `cli_cep`, `cli_cidade`, `cli_uf`, `cli_email`, `cli_fone_w`)
                //VALUES(NULL, 'LIMPEZA', 'SABAO EM PÓ', '5', '7', '1');

                comandoMySql.CommandText = "INSERT INTO modelo (mod_marca, mod_desc, mod_ativo)" +
                        "VALUES('" + tb_M_marca.Text + "', '" + tb_M_desc.Text + "', '" + cbx_M_apto.Text + "')";
                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close();
                MessageBox.Show("Modelo de veículo Cadastrado com Sucesso!");
                AtualizaGridMod();
                LimparCamposV();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }            
        }

        private void bt_M_alterar_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open(); //Abre a conexão com o banco
                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand(); //Crio um comando SQL

                comandoMySql.CommandText = "UPDATE modelo SET mod_marca = '" + tb_M_marca.Text + "', " +
                    "mod_desc = '" + tb_M_desc.Text + "', " +
                    "mod_ativo = '" + cbx_M_apto.Text + "' " +
                    " WHERE mod_id  = '" + tb_M_cod.Text + "'";
                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close(); // Fecho a conexão com o banco
                MessageBox.Show("Dados Atualizado com Sucesso!"); //Exibo mensagem de aviso
                AtualizaGridMod();
                LimparCamposV();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void bt_M_excluir_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open(); //Abre a conexão com o banco

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand(); //Crio um comando SQL
                                                                               // "DELETE FROM filme WHERE idFilme = "+ textBoxId.Text +""
                                                                               //comandoMySql.CommandText = "DELETE FROM filme WHERE idFilme = " + tbID.Text + "";
                comandoMySql.CommandText = "DELETE from modelo WHERE modelo.mod_id = " + tb_M_cod.Text + "";

                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close(); // Fecho a conexão com o banco
                MessageBox.Show("Modelo de Veículo Deletado com Sucesso!"); //Exibo mensagem de aviso
                AtualizaGridMod();
                LimparCamposV();
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Não foi possivel abrir a conexão! ");
                Console.WriteLine(ex.Message);
            }
        }

        private void Dtg_CM_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dtg_CM.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                dtg_CM.CurrentRow.Selected = true;
                //preenche os textbox com as células da linha selecionada
                tb_CM_cod.Text = dtg_CM.Rows[e.RowIndex].Cells["colCMid"].FormattedValue.ToString();
                tb_CM_desc.Text = dtg_CM.Rows[e.RowIndex].Cells["colCMdesc"].FormattedValue.ToString();
                cbx_CM_ativo.Text = dtg_CM.Rows[e.RowIndex].Cells["colCativo"].FormattedValue.ToString();
            }
        }

        private void Bt_CM_limpar_Click(object sender, EventArgs e)
        {
            LimparCamposCM();
        }
        private void LimparCamposCM()
        {
            tb_CM_cod.Clear();
            tb_CM_desc.Clear();
            cbx_CM_ativo.SelectedIndex = -1;
        }

        private void Bt_CM_excluir_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open(); //Abre a conexão com o banco

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand(); //Crio um comando SQL
                                                                               // "DELETE FROM filme WHERE idFilme = "+ textBoxId.Text +""
                                                                               //comandoMySql.CommandText = "DELETE FROM filme WHERE idFilme = " + tbID.Text + "";
                comandoMySql.CommandText = "DELETE from marca WHERE marca.mar_id = " + tb_CM_cod.Text + "";

                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close(); // Fecho a conexão com o banco
                MessageBox.Show("Marca de Veículo Deletado com Sucesso!"); //Exibo mensagem de aviso
                AtualizaGridMar();
                LimparCamposCM();
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Não foi possivel abrir a conexão! ");
                Console.WriteLine(ex.Message);
            }
        }

        private void Bt_CM_listar_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open();

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand();
                comandoMySql.CommandText = "SELECT * FROM marca WHERE mar_id = '" + tb_CM_cod.Text + "'";
                MySqlDataReader reader = comandoMySql.ExecuteReader();

                //dgLocadora.Rows.Clear();

                while (reader.Read())
                {
                    tb_CM_cod.Text = reader.GetString(0);     // Modelo id
                    tb_CM_desc.Text = reader.GetString(1);    // Modelo descrição
                    cbx_CM_ativo.Text = reader.GetString(2);    // Modelo descrição

                }

                realizaConexacoBD.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Banco de dados fora do AR! ");
                Console.WriteLine(ex.Message);
            }
        }

        private void Bt_CM_alterar_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open(); //Abre a conexão com o banco
                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand(); //Crio um comando SQL

                comandoMySql.CommandText = "UPDATE marca SET mar_desc = '" + tb_CM_desc.Text + "', " +
                    "mar_ativo = '" + cbx_CM_ativo.Text + "' " +
                    " WHERE mar_id = " + tb_CM_cod.Text + "";
                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close(); // Fecho a conexão com o banco
                MessageBox.Show("Dados Atualizado com Sucesso!"); //Exibo mensagem de aviso
                AtualizaGridMar();
                LimparCamposCM();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void Bt_CM_cad_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open();

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand();

                //INSERT INTO `cliente` (`id`, `cli_cpf`, `cli_nome`, `cli_end`, `cli_bairro`, `cli_cep`, `cli_cidade`, `cli_uf`, `cli_email`, `cli_fone_w`)
                //VALUES(NULL, 'LIMPEZA', 'SABAO EM PÓ', '5', '7', '1');

                comandoMySql.CommandText = "INSERT INTO marca (mar_desc, mar_ativo)" +
                        "VALUES('" + tb_CM_desc.Text + "', '" + cbx_CM_ativo.Text + "')";
                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close();
                MessageBox.Show("Marca de veículo Cadastrado com Sucesso!");
                AtualizaGridMar();
                LimparCamposCM();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
