﻿
namespace DEVJR_rent_a_car
{
    partial class F_Dev_Jr
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(F_Dev_Jr));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.lOCAÇÃOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vENDASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.sAIRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cADASTROToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.veiculosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funcionáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fornecedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.cLIENTESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.P_CadCli = new System.Windows.Forms.Panel();
            this.Bt_Update = new System.Windows.Forms.Button();
            this.Bt_Altera = new System.Windows.Forms.Button();
            this.Bt_Busca = new System.Windows.Forms.Button();
            this.Bt_CadCli = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.TB_FoneW = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TB_Email = new System.Windows.Forms.TextBox();
            this.CB_UF = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TB_Cidade = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.TB_CEP = new System.Windows.Forms.TextBox();
            this.CB_Bairro = new System.Windows.Forms.ComboBox();
            this.LBairro = new System.Windows.Forms.Label();
            this.LEnd = new System.Windows.Forms.Label();
            this.TB_End = new System.Windows.Forms.TextBox();
            this.LNome = new System.Windows.Forms.Label();
            this.TB_Nome = new System.Windows.Forms.TextBox();
            this.LCPF = new System.Windows.Forms.Label();
            this.TB_CPF = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.P_CadCli.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.cADASTROToolStripMenuItem});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lOCAÇÃOToolStripMenuItem,
            this.vENDASToolStripMenuItem,
            this.toolStripMenuItem2,
            this.sAIRToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            resources.ApplyResources(this.toolStripMenuItem1, "toolStripMenuItem1");
            // 
            // lOCAÇÃOToolStripMenuItem
            // 
            this.lOCAÇÃOToolStripMenuItem.Name = "lOCAÇÃOToolStripMenuItem";
            resources.ApplyResources(this.lOCAÇÃOToolStripMenuItem, "lOCAÇÃOToolStripMenuItem");
            // 
            // vENDASToolStripMenuItem
            // 
            this.vENDASToolStripMenuItem.Name = "vENDASToolStripMenuItem";
            resources.ApplyResources(this.vENDASToolStripMenuItem, "vENDASToolStripMenuItem");
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            resources.ApplyResources(this.toolStripMenuItem2, "toolStripMenuItem2");
            // 
            // sAIRToolStripMenuItem
            // 
            this.sAIRToolStripMenuItem.Name = "sAIRToolStripMenuItem";
            resources.ApplyResources(this.sAIRToolStripMenuItem, "sAIRToolStripMenuItem");
            this.sAIRToolStripMenuItem.Click += new System.EventHandler(this.SAIRToolStripMenuItem_Click);
            // 
            // cADASTROToolStripMenuItem
            // 
            this.cADASTROToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.veiculosToolStripMenuItem,
            this.funcionáriosToolStripMenuItem,
            this.fornecedoresToolStripMenuItem,
            this.toolStripMenuItem3,
            this.cLIENTESToolStripMenuItem});
            this.cADASTROToolStripMenuItem.Name = "cADASTROToolStripMenuItem";
            resources.ApplyResources(this.cADASTROToolStripMenuItem, "cADASTROToolStripMenuItem");
            this.cADASTROToolStripMenuItem.Click += new System.EventHandler(this.CADASTROToolStripMenuItem_Click);
            // 
            // veiculosToolStripMenuItem
            // 
            this.veiculosToolStripMenuItem.Name = "veiculosToolStripMenuItem";
            resources.ApplyResources(this.veiculosToolStripMenuItem, "veiculosToolStripMenuItem");
            // 
            // funcionáriosToolStripMenuItem
            // 
            this.funcionáriosToolStripMenuItem.Name = "funcionáriosToolStripMenuItem";
            resources.ApplyResources(this.funcionáriosToolStripMenuItem, "funcionáriosToolStripMenuItem");
            // 
            // fornecedoresToolStripMenuItem
            // 
            this.fornecedoresToolStripMenuItem.Name = "fornecedoresToolStripMenuItem";
            resources.ApplyResources(this.fornecedoresToolStripMenuItem, "fornecedoresToolStripMenuItem");
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            resources.ApplyResources(this.toolStripMenuItem3, "toolStripMenuItem3");
            // 
            // cLIENTESToolStripMenuItem
            // 
            this.cLIENTESToolStripMenuItem.Name = "cLIENTESToolStripMenuItem";
            resources.ApplyResources(this.cLIENTESToolStripMenuItem, "cLIENTESToolStripMenuItem");
            this.cLIENTESToolStripMenuItem.Click += new System.EventHandler(this.CLIENTESToolStripMenuItem_Click);
            // 
            // P_CadCli
            // 
            resources.ApplyResources(this.P_CadCli, "P_CadCli");
            this.P_CadCli.Controls.Add(this.Bt_Update);
            this.P_CadCli.Controls.Add(this.Bt_Altera);
            this.P_CadCli.Controls.Add(this.Bt_Busca);
            this.P_CadCli.Controls.Add(this.Bt_CadCli);
            this.P_CadCli.Controls.Add(this.label5);
            this.P_CadCli.Controls.Add(this.TB_FoneW);
            this.P_CadCli.Controls.Add(this.label4);
            this.P_CadCli.Controls.Add(this.TB_Email);
            this.P_CadCli.Controls.Add(this.CB_UF);
            this.P_CadCli.Controls.Add(this.label3);
            this.P_CadCli.Controls.Add(this.label2);
            this.P_CadCli.Controls.Add(this.TB_Cidade);
            this.P_CadCli.Controls.Add(this.label1);
            this.P_CadCli.Controls.Add(this.TB_CEP);
            this.P_CadCli.Controls.Add(this.CB_Bairro);
            this.P_CadCli.Controls.Add(this.LBairro);
            this.P_CadCli.Controls.Add(this.LEnd);
            this.P_CadCli.Controls.Add(this.TB_End);
            this.P_CadCli.Controls.Add(this.LNome);
            this.P_CadCli.Controls.Add(this.TB_Nome);
            this.P_CadCli.Controls.Add(this.LCPF);
            this.P_CadCli.Controls.Add(this.TB_CPF);
            this.P_CadCli.Name = "P_CadCli";
            this.P_CadCli.Paint += new System.Windows.Forms.PaintEventHandler(this.P_CadCli_Paint);
            // 
            // Bt_Update
            // 
            this.Bt_Update.ForeColor = System.Drawing.Color.OrangeRed;
            resources.ApplyResources(this.Bt_Update, "Bt_Update");
            this.Bt_Update.Name = "Bt_Update";
            this.Bt_Update.UseVisualStyleBackColor = true;
            // 
            // Bt_Altera
            // 
            this.Bt_Altera.ForeColor = System.Drawing.Color.LightSlateGray;
            resources.ApplyResources(this.Bt_Altera, "Bt_Altera");
            this.Bt_Altera.Name = "Bt_Altera";
            this.Bt_Altera.UseVisualStyleBackColor = true;
            // 
            // Bt_Busca
            // 
            this.Bt_Busca.ForeColor = System.Drawing.Color.LightSeaGreen;
            resources.ApplyResources(this.Bt_Busca, "Bt_Busca");
            this.Bt_Busca.Name = "Bt_Busca";
            this.Bt_Busca.UseVisualStyleBackColor = true;
            this.Bt_Busca.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Bt_CadCli
            // 
            this.Bt_CadCli.ForeColor = System.Drawing.Color.DarkGreen;
            resources.ApplyResources(this.Bt_CadCli, "Bt_CadCli");
            this.Bt_CadCli.Name = "Bt_CadCli";
            this.Bt_CadCli.UseVisualStyleBackColor = true;
            this.Bt_CadCli.Click += new System.EventHandler(this.Bt_CadCli_Click);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // TB_FoneW
            // 
            resources.ApplyResources(this.TB_FoneW, "TB_FoneW");
            this.TB_FoneW.Name = "TB_FoneW";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // TB_Email
            // 
            resources.ApplyResources(this.TB_Email, "TB_Email");
            this.TB_Email.Name = "TB_Email";
            // 
            // CB_UF
            // 
            this.CB_UF.FormattingEnabled = true;
            this.CB_UF.Items.AddRange(new object[] {
            resources.GetString("CB_UF.Items"),
            resources.GetString("CB_UF.Items1"),
            resources.GetString("CB_UF.Items2"),
            resources.GetString("CB_UF.Items3"),
            resources.GetString("CB_UF.Items4"),
            resources.GetString("CB_UF.Items5"),
            resources.GetString("CB_UF.Items6"),
            resources.GetString("CB_UF.Items7"),
            resources.GetString("CB_UF.Items8"),
            resources.GetString("CB_UF.Items9"),
            resources.GetString("CB_UF.Items10"),
            resources.GetString("CB_UF.Items11"),
            resources.GetString("CB_UF.Items12"),
            resources.GetString("CB_UF.Items13"),
            resources.GetString("CB_UF.Items14"),
            resources.GetString("CB_UF.Items15"),
            resources.GetString("CB_UF.Items16"),
            resources.GetString("CB_UF.Items17"),
            resources.GetString("CB_UF.Items18"),
            resources.GetString("CB_UF.Items19"),
            resources.GetString("CB_UF.Items20"),
            resources.GetString("CB_UF.Items21"),
            resources.GetString("CB_UF.Items22"),
            resources.GetString("CB_UF.Items23"),
            resources.GetString("CB_UF.Items24"),
            resources.GetString("CB_UF.Items25"),
            resources.GetString("CB_UF.Items26")});
            resources.ApplyResources(this.CB_UF, "CB_UF");
            this.CB_UF.Name = "CB_UF";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // TB_Cidade
            // 
            resources.ApplyResources(this.TB_Cidade, "TB_Cidade");
            this.TB_Cidade.Name = "TB_Cidade";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // TB_CEP
            // 
            resources.ApplyResources(this.TB_CEP, "TB_CEP");
            this.TB_CEP.Name = "TB_CEP";
            // 
            // CB_Bairro
            // 
            this.CB_Bairro.FormattingEnabled = true;
            this.CB_Bairro.Items.AddRange(new object[] {
            resources.GetString("CB_Bairro.Items"),
            resources.GetString("CB_Bairro.Items1"),
            resources.GetString("CB_Bairro.Items2"),
            resources.GetString("CB_Bairro.Items3"),
            resources.GetString("CB_Bairro.Items4"),
            resources.GetString("CB_Bairro.Items5"),
            resources.GetString("CB_Bairro.Items6"),
            resources.GetString("CB_Bairro.Items7"),
            resources.GetString("CB_Bairro.Items8"),
            resources.GetString("CB_Bairro.Items9"),
            resources.GetString("CB_Bairro.Items10"),
            resources.GetString("CB_Bairro.Items11"),
            resources.GetString("CB_Bairro.Items12"),
            resources.GetString("CB_Bairro.Items13"),
            resources.GetString("CB_Bairro.Items14"),
            resources.GetString("CB_Bairro.Items15"),
            resources.GetString("CB_Bairro.Items16"),
            resources.GetString("CB_Bairro.Items17"),
            resources.GetString("CB_Bairro.Items18"),
            resources.GetString("CB_Bairro.Items19"),
            resources.GetString("CB_Bairro.Items20"),
            resources.GetString("CB_Bairro.Items21"),
            resources.GetString("CB_Bairro.Items22"),
            resources.GetString("CB_Bairro.Items23"),
            resources.GetString("CB_Bairro.Items24"),
            resources.GetString("CB_Bairro.Items25"),
            resources.GetString("CB_Bairro.Items26"),
            resources.GetString("CB_Bairro.Items27"),
            resources.GetString("CB_Bairro.Items28"),
            resources.GetString("CB_Bairro.Items29"),
            resources.GetString("CB_Bairro.Items30"),
            resources.GetString("CB_Bairro.Items31")});
            resources.ApplyResources(this.CB_Bairro, "CB_Bairro");
            this.CB_Bairro.Name = "CB_Bairro";
            this.CB_Bairro.SelectedIndexChanged += new System.EventHandler(this.ComboBox1_SelectedIndexChanged);
            // 
            // LBairro
            // 
            resources.ApplyResources(this.LBairro, "LBairro");
            this.LBairro.Name = "LBairro";
            // 
            // LEnd
            // 
            resources.ApplyResources(this.LEnd, "LEnd");
            this.LEnd.Name = "LEnd";
            this.LEnd.Click += new System.EventHandler(this.Label2_Click);
            // 
            // TB_End
            // 
            resources.ApplyResources(this.TB_End, "TB_End");
            this.TB_End.Name = "TB_End";
            this.TB_End.TextChanged += new System.EventHandler(this.TextBox3_TextChanged);
            // 
            // LNome
            // 
            resources.ApplyResources(this.LNome, "LNome");
            this.LNome.Name = "LNome";
            this.LNome.Click += new System.EventHandler(this.Label1_Click_1);
            // 
            // TB_Nome
            // 
            resources.ApplyResources(this.TB_Nome, "TB_Nome");
            this.TB_Nome.Name = "TB_Nome";
            // 
            // LCPF
            // 
            resources.ApplyResources(this.LCPF, "LCPF");
            this.LCPF.Name = "LCPF";
            this.LCPF.Click += new System.EventHandler(this.TCPF_Click);
            // 
            // TB_CPF
            // 
            resources.ApplyResources(this.TB_CPF, "TB_CPF");
            this.TB_CPF.ForeColor = System.Drawing.Color.Maroon;
            this.TB_CPF.Name = "TB_CPF";
            this.TB_CPF.TextChanged += new System.EventHandler(this.TB_CPF_TextChanged);
            // 
            // F_Dev_Jr
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ControlBox = false;
            this.Controls.Add(this.P_CadCli);
            this.Controls.Add(this.menuStrip1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "F_Dev_Jr";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.TopMost = true;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.P_CadCli.ResumeLayout(false);
            this.P_CadCli.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem lOCAÇÃOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cADASTROToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vENDASToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem sAIRToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem veiculosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funcionáriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fornecedoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem cLIENTESToolStripMenuItem;
        private System.Windows.Forms.Panel P_CadCli;
        private System.Windows.Forms.TextBox TB_CPF;
        private System.Windows.Forms.Label LCPF;
        private System.Windows.Forms.Label LNome;
        private System.Windows.Forms.TextBox TB_Nome;
        private System.Windows.Forms.Label LEnd;
        private System.Windows.Forms.TextBox TB_End;
        private System.Windows.Forms.ComboBox CB_Bairro;
        private System.Windows.Forms.Label LBairro;
        private System.Windows.Forms.ComboBox CB_UF;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TB_Cidade;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_CEP;
        private System.Windows.Forms.Button Bt_CadCli;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TB_FoneW;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TB_Email;
        private System.Windows.Forms.Button Bt_Busca;
        private System.Windows.Forms.Button Bt_Altera;
        private System.Windows.Forms.Button Bt_Update;
        private System.Windows.Forms.MenuStrip menuStrip1;
    }
}

