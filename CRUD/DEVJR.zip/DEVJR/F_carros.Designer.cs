﻿
namespace DEVJR
{
    partial class F_carros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(F_carros));
            this.P_Carros = new System.Windows.Forms.Panel();
            this.bt_Sair = new System.Windows.Forms.Button();
            this.lb_Veiculos = new System.Windows.Forms.Label();
            this.tb_Veiculos = new System.Windows.Forms.TabControl();
            this.tbVeiculos = new System.Windows.Forms.TabPage();
            this.btExcluir = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.dtg_V = new System.Windows.Forms.DataGridView();
            this.bt_C_cad = new System.Windows.Forms.Button();
            this.bt_V_limpa = new System.Windows.Forms.Button();
            this.P_veiculo = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.car_apto = new System.Windows.Forms.ComboBox();
            this.tb_V_obs = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cb_V_cor = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_V_ano = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_V_codmod = new System.Windows.Forms.TextBox();
            this.lbl_V_codmod = new System.Windows.Forms.Label();
            this.tb_V_cod = new System.Windows.Forms.TextBox();
            this.lbl_V_cod = new System.Windows.Forms.Label();
            this.tb_V_desc = new System.Windows.Forms.TextBox();
            this.lbl_V_desc = new System.Windows.Forms.Label();
            this.bt_C_altera = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.bt_C_lista = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tbMarca = new System.Windows.Forms.TabPage();
            this.bt_CM_excluir = new System.Windows.Forms.Button();
            this.P_CM_grid = new System.Windows.Forms.Panel();
            this.dtg_CM = new System.Windows.Forms.DataGridView();
            this.bt_CM_cad = new System.Windows.Forms.Button();
            this.bt_CM_limpar = new System.Windows.Forms.Button();
            this.P_CM = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cbx_CM_ativo = new System.Windows.Forms.ComboBox();
            this.tb_CM_cod = new System.Windows.Forms.TextBox();
            this.lbl_CM_codmar = new System.Windows.Forms.Label();
            this.tb_CM_desc = new System.Windows.Forms.TextBox();
            this.lbl_CM_desc = new System.Windows.Forms.Label();
            this.bt_CM_alterar = new System.Windows.Forms.Button();
            this.lbl_CM_marcas = new System.Windows.Forms.Label();
            this.lbl_CM_controlede = new System.Windows.Forms.Label();
            this.bt_CM_listar = new System.Windows.Forms.Button();
            this.tbModelo = new System.Windows.Forms.TabPage();
            this.bt_M_excluir = new System.Windows.Forms.Button();
            this.bt_M_cadastrar = new System.Windows.Forms.Button();
            this.bt_M_limpar = new System.Windows.Forms.Button();
            this.bt_M_alterar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.bt_M_Listar = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dtg_Mod = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cbx_M_apto = new System.Windows.Forms.ComboBox();
            this.tb_M_marca = new System.Windows.Forms.TextBox();
            this.lbl_MD_cmarcas = new System.Windows.Forms.Label();
            this.tb_M_cod = new System.Windows.Forms.TextBox();
            this.lbl_MD_cod = new System.Windows.Forms.Label();
            this.tb_M_desc = new System.Windows.Forms.TextBox();
            this.lbl_MD_descricao = new System.Windows.Forms.Label();
            this.colVcod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colVdesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colVmod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colVano = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colVcor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colVobs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colVapto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMDcod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMDmar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMDdesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMDativo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCMid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCMdesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCativo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.P_Carros.SuspendLayout();
            this.tb_Veiculos.SuspendLayout();
            this.tbVeiculos.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_V)).BeginInit();
            this.P_veiculo.SuspendLayout();
            this.tbMarca.SuspendLayout();
            this.P_CM_grid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_CM)).BeginInit();
            this.P_CM.SuspendLayout();
            this.tbModelo.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Mod)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // P_Carros
            // 
            this.P_Carros.BackColor = System.Drawing.Color.White;
            this.P_Carros.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.P_Carros.Controls.Add(this.bt_Sair);
            this.P_Carros.Controls.Add(this.lb_Veiculos);
            this.P_Carros.Controls.Add(this.tb_Veiculos);
            this.P_Carros.Location = new System.Drawing.Point(0, 0);
            this.P_Carros.Name = "P_Carros";
            this.P_Carros.Size = new System.Drawing.Size(678, 553);
            this.P_Carros.TabIndex = 0;
            this.P_Carros.Paint += new System.Windows.Forms.PaintEventHandler(this.P_Carros_Paint);
            // 
            // bt_Sair
            // 
            this.bt_Sair.BackColor = System.Drawing.Color.Red;
            this.bt_Sair.FlatAppearance.BorderSize = 0;
            this.bt_Sair.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_Sair.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_Sair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_Sair.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Sair.ForeColor = System.Drawing.Color.White;
            this.bt_Sair.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_Sair.Location = new System.Drawing.Point(631, 21);
            this.bt_Sair.Name = "bt_Sair";
            this.bt_Sair.Size = new System.Drawing.Size(37, 23);
            this.bt_Sair.TabIndex = 38;
            this.bt_Sair.Text = "&SAIR";
            this.bt_Sair.UseVisualStyleBackColor = false;
            this.bt_Sair.Click += new System.EventHandler(this.bt_Sair_Click);
            // 
            // lb_Veiculos
            // 
            this.lb_Veiculos.AutoSize = true;
            this.lb_Veiculos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Veiculos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Veiculos.Location = new System.Drawing.Point(9, 23);
            this.lb_Veiculos.Name = "lb_Veiculos";
            this.lb_Veiculos.Size = new System.Drawing.Size(101, 22);
            this.lb_Veiculos.TabIndex = 44;
            this.lb_Veiculos.Text = "VEÍCULOS";
            this.lb_Veiculos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_Veiculos.Click += new System.EventHandler(this.label7_Click);
            // 
            // tb_Veiculos
            // 
            this.tb_Veiculos.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tb_Veiculos.Controls.Add(this.tbVeiculos);
            this.tb_Veiculos.Controls.Add(this.tbMarca);
            this.tb_Veiculos.Controls.Add(this.tbModelo);
            this.tb_Veiculos.Cursor = System.Windows.Forms.Cursors.Default;
            this.tb_Veiculos.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.tb_Veiculos.Location = new System.Drawing.Point(4, 50);
            this.tb_Veiculos.Name = "tb_Veiculos";
            this.tb_Veiculos.SelectedIndex = 0;
            this.tb_Veiculos.Size = new System.Drawing.Size(671, 503);
            this.tb_Veiculos.TabIndex = 0;
            this.tb_Veiculos.SelectedIndexChanged += new System.EventHandler(this.tb_Veiculos_SelectedIndexChanged);
            // 
            // tbVeiculos
            // 
            this.tbVeiculos.BackColor = System.Drawing.Color.White;
            this.tbVeiculos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tbVeiculos.Controls.Add(this.btExcluir);
            this.tbVeiculos.Controls.Add(this.panel6);
            this.tbVeiculos.Controls.Add(this.bt_C_cad);
            this.tbVeiculos.Controls.Add(this.bt_V_limpa);
            this.tbVeiculos.Controls.Add(this.P_veiculo);
            this.tbVeiculos.Controls.Add(this.bt_C_altera);
            this.tbVeiculos.Controls.Add(this.label9);
            this.tbVeiculos.Controls.Add(this.bt_C_lista);
            this.tbVeiculos.Controls.Add(this.label5);
            this.tbVeiculos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbVeiculos.Location = new System.Drawing.Point(4, 4);
            this.tbVeiculos.Margin = new System.Windows.Forms.Padding(0);
            this.tbVeiculos.Name = "tbVeiculos";
            this.tbVeiculos.Size = new System.Drawing.Size(663, 477);
            this.tbVeiculos.TabIndex = 2;
            this.tbVeiculos.Text = "VEÍCULOS";
            this.tbVeiculos.Click += new System.EventHandler(this.tbVeiculos_Click);
            // 
            // btExcluir
            // 
            this.btExcluir.BackColor = System.Drawing.Color.OrangeRed;
            this.btExcluir.FlatAppearance.BorderSize = 0;
            this.btExcluir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btExcluir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.btExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btExcluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btExcluir.ForeColor = System.Drawing.Color.White;
            this.btExcluir.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btExcluir.Location = new System.Drawing.Point(219, 411);
            this.btExcluir.Name = "btExcluir";
            this.btExcluir.Size = new System.Drawing.Size(71, 45);
            this.btExcluir.TabIndex = 77;
            this.btExcluir.Text = "E&XCLUIR";
            this.btExcluir.UseVisualStyleBackColor = false;
            this.btExcluir.Click += new System.EventHandler(this.btExcluir_Click);
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.dtg_V);
            this.panel6.Location = new System.Drawing.Point(2, 213);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(660, 177);
            this.panel6.TabIndex = 50;
            // 
            // dtg_V
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtg_V.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtg_V.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_V.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colVcod,
            this.colVdesc,
            this.colVmod,
            this.colVano,
            this.colVcor,
            this.colVobs,
            this.colVapto});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtg_V.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtg_V.Location = new System.Drawing.Point(19, 20);
            this.dtg_V.Name = "dtg_V";
            this.dtg_V.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtg_V.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dtg_V.Size = new System.Drawing.Size(620, 139);
            this.dtg_V.TabIndex = 49;
            this.dtg_V.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Dtg_V_CellContentClick);
            // 
            // bt_C_cad
            // 
            this.bt_C_cad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.bt_C_cad.FlatAppearance.BorderSize = 0;
            this.bt_C_cad.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_C_cad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_C_cad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_C_cad.ForeColor = System.Drawing.Color.White;
            this.bt_C_cad.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_C_cad.Location = new System.Drawing.Point(498, 411);
            this.bt_C_cad.Name = "bt_C_cad";
            this.bt_C_cad.Size = new System.Drawing.Size(144, 45);
            this.bt_C_cad.TabIndex = 76;
            this.bt_C_cad.Text = "&CADASTRAR";
            this.bt_C_cad.UseVisualStyleBackColor = false;
            this.bt_C_cad.Click += new System.EventHandler(this.Bt_C_cad_Click);
            // 
            // bt_V_limpa
            // 
            this.bt_V_limpa.BackColor = System.Drawing.Color.Orange;
            this.bt_V_limpa.FlatAppearance.BorderSize = 0;
            this.bt_V_limpa.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_V_limpa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_V_limpa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_V_limpa.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_V_limpa.ForeColor = System.Drawing.Color.White;
            this.bt_V_limpa.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_V_limpa.Location = new System.Drawing.Point(157, 411);
            this.bt_V_limpa.Name = "bt_V_limpa";
            this.bt_V_limpa.Size = new System.Drawing.Size(56, 45);
            this.bt_V_limpa.TabIndex = 73;
            this.bt_V_limpa.Text = "L&IMPAR";
            this.bt_V_limpa.UseVisualStyleBackColor = false;
            this.bt_V_limpa.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // P_veiculo
            // 
            this.P_veiculo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.P_veiculo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.P_veiculo.Controls.Add(this.label10);
            this.P_veiculo.Controls.Add(this.label11);
            this.P_veiculo.Controls.Add(this.car_apto);
            this.P_veiculo.Controls.Add(this.tb_V_obs);
            this.P_veiculo.Controls.Add(this.label4);
            this.P_veiculo.Controls.Add(this.cb_V_cor);
            this.P_veiculo.Controls.Add(this.label1);
            this.P_veiculo.Controls.Add(this.tb_V_ano);
            this.P_veiculo.Controls.Add(this.label2);
            this.P_veiculo.Controls.Add(this.tb_V_codmod);
            this.P_veiculo.Controls.Add(this.lbl_V_codmod);
            this.P_veiculo.Controls.Add(this.tb_V_cod);
            this.P_veiculo.Controls.Add(this.lbl_V_cod);
            this.P_veiculo.Controls.Add(this.tb_V_desc);
            this.P_veiculo.Controls.Add(this.lbl_V_desc);
            this.P_veiculo.Location = new System.Drawing.Point(2, 0);
            this.P_veiculo.Name = "P_veiculo";
            this.P_veiculo.Size = new System.Drawing.Size(660, 214);
            this.P_veiculo.TabIndex = 37;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(30, 174);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(156, 9);
            this.label10.TabIndex = 54;
            this.label10.Text = "Veículos Aptos Podem ser Locados";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(58, 187);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(128, 9);
            this.label11.TabIndex = 55;
            this.label11.Text = "Não APTO\'s - Ir pra vistoria";
            // 
            // car_apto
            // 
            this.car_apto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.car_apto.ForeColor = System.Drawing.Color.OrangeRed;
            this.car_apto.FormattingEnabled = true;
            this.car_apto.Items.AddRange(new object[] {
            "APTO",
            "NÃO APTO"});
            this.car_apto.Location = new System.Drawing.Point(190, 174);
            this.car_apto.Name = "car_apto";
            this.car_apto.Size = new System.Drawing.Size(121, 21);
            this.car_apto.TabIndex = 51;
            // 
            // tb_V_obs
            // 
            this.tb_V_obs.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tb_V_obs.Location = new System.Drawing.Point(128, 119);
            this.tb_V_obs.Multiline = true;
            this.tb_V_obs.Name = "tb_V_obs";
            this.tb_V_obs.Size = new System.Drawing.Size(493, 42);
            this.tb_V_obs.TabIndex = 45;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(38, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 13);
            this.label4.TabIndex = 46;
            this.label4.Text = "Observação:";
            // 
            // cb_V_cor
            // 
            this.cb_V_cor.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cb_V_cor.FormattingEnabled = true;
            this.cb_V_cor.Items.AddRange(new object[] {
            "Branco",
            "Prata",
            "Preto",
            "Cinza",
            "Vermelho",
            "Azul",
            "Marrom",
            "Verde",
            "Amarelo"});
            this.cb_V_cor.Location = new System.Drawing.Point(443, 51);
            this.cb_V_cor.Name = "cb_V_cor";
            this.cb_V_cor.Size = new System.Drawing.Size(178, 29);
            this.cb_V_cor.TabIndex = 44;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(401, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 42;
            this.label1.Text = "Cor:";
            // 
            // tb_V_ano
            // 
            this.tb_V_ano.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tb_V_ano.ForeColor = System.Drawing.Color.Maroon;
            this.tb_V_ano.Location = new System.Drawing.Point(534, 17);
            this.tb_V_ano.Name = "tb_V_ano";
            this.tb_V_ano.Size = new System.Drawing.Size(87, 29);
            this.tb_V_ano.TabIndex = 41;
            this.tb_V_ano.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(494, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 40;
            this.label2.Text = "Ano:";
            // 
            // tb_V_codmod
            // 
            this.tb_V_codmod.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tb_V_codmod.ForeColor = System.Drawing.Color.Maroon;
            this.tb_V_codmod.Location = new System.Drawing.Point(128, 51);
            this.tb_V_codmod.Name = "tb_V_codmod";
            this.tb_V_codmod.Size = new System.Drawing.Size(184, 29);
            this.tb_V_codmod.TabIndex = 39;
            // 
            // lbl_V_codmod
            // 
            this.lbl_V_codmod.AutoSize = true;
            this.lbl_V_codmod.Location = new System.Drawing.Point(38, 59);
            this.lbl_V_codmod.Name = "lbl_V_codmod";
            this.lbl_V_codmod.Size = new System.Drawing.Size(85, 13);
            this.lbl_V_codmod.TabIndex = 38;
            this.lbl_V_codmod.Text = "Cód. do Modelo:";
            // 
            // tb_V_cod
            // 
            this.tb_V_cod.BackColor = System.Drawing.Color.White;
            this.tb_V_cod.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_V_cod.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tb_V_cod.ForeColor = System.Drawing.Color.Turquoise;
            this.tb_V_cod.Location = new System.Drawing.Point(128, 17);
            this.tb_V_cod.Name = "tb_V_cod";
            this.tb_V_cod.Size = new System.Drawing.Size(82, 29);
            this.tb_V_cod.TabIndex = 32;
            // 
            // lbl_V_cod
            // 
            this.lbl_V_cod.AutoSize = true;
            this.lbl_V_cod.Location = new System.Drawing.Point(38, 25);
            this.lbl_V_cod.Name = "lbl_V_cod";
            this.lbl_V_cod.Size = new System.Drawing.Size(72, 13);
            this.lbl_V_cod.TabIndex = 29;
            this.lbl_V_cod.Text = "Cód. Veículo:";
            // 
            // tb_V_desc
            // 
            this.tb_V_desc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_V_desc.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.tb_V_desc.Location = new System.Drawing.Point(128, 85);
            this.tb_V_desc.Name = "tb_V_desc";
            this.tb_V_desc.Size = new System.Drawing.Size(493, 29);
            this.tb_V_desc.TabIndex = 2;
            // 
            // lbl_V_desc
            // 
            this.lbl_V_desc.AutoSize = true;
            this.lbl_V_desc.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_V_desc.Location = new System.Drawing.Point(38, 93);
            this.lbl_V_desc.Name = "lbl_V_desc";
            this.lbl_V_desc.Size = new System.Drawing.Size(58, 13);
            this.lbl_V_desc.TabIndex = 3;
            this.lbl_V_desc.Text = "Descrição:";
            // 
            // bt_C_altera
            // 
            this.bt_C_altera.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(98)))), ((int)(((byte)(97)))));
            this.bt_C_altera.FlatAppearance.BorderSize = 0;
            this.bt_C_altera.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_C_altera.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_C_altera.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_C_altera.ForeColor = System.Drawing.Color.White;
            this.bt_C_altera.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_C_altera.Location = new System.Drawing.Point(397, 411);
            this.bt_C_altera.Name = "bt_C_altera";
            this.bt_C_altera.Size = new System.Drawing.Size(94, 45);
            this.bt_C_altera.TabIndex = 75;
            this.bt_C_altera.Text = "&ALTERAR";
            this.bt_C_altera.UseVisualStyleBackColor = false;
            this.bt_C_altera.Click += new System.EventHandler(this.bt_C_altera_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(22, 413);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(125, 22);
            this.label9.TabIndex = 71;
            this.label9.Text = "CONTROLE DE";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bt_C_lista
            // 
            this.bt_C_lista.BackColor = System.Drawing.Color.CadetBlue;
            this.bt_C_lista.FlatAppearance.BorderSize = 0;
            this.bt_C_lista.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_C_lista.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_C_lista.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_C_lista.ForeColor = System.Drawing.Color.White;
            this.bt_C_lista.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_C_lista.Location = new System.Drawing.Point(296, 411);
            this.bt_C_lista.Name = "bt_C_lista";
            this.bt_C_lista.Size = new System.Drawing.Size(94, 45);
            this.bt_C_lista.TabIndex = 74;
            this.bt_C_lista.Text = "&LISTAR";
            this.bt_C_lista.UseVisualStyleBackColor = false;
            this.bt_C_lista.Click += new System.EventHandler(this.bt_C_lista_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(47, 434);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 22);
            this.label5.TabIndex = 72;
            this.label5.Text = "VEÍCULOS";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbMarca
            // 
            this.tbMarca.BackColor = System.Drawing.Color.White;
            this.tbMarca.Controls.Add(this.bt_CM_excluir);
            this.tbMarca.Controls.Add(this.P_CM_grid);
            this.tbMarca.Controls.Add(this.bt_CM_cad);
            this.tbMarca.Controls.Add(this.bt_CM_limpar);
            this.tbMarca.Controls.Add(this.P_CM);
            this.tbMarca.Controls.Add(this.bt_CM_alterar);
            this.tbMarca.Controls.Add(this.lbl_CM_marcas);
            this.tbMarca.Controls.Add(this.lbl_CM_controlede);
            this.tbMarca.Controls.Add(this.bt_CM_listar);
            this.tbMarca.Location = new System.Drawing.Point(4, 4);
            this.tbMarca.Name = "tbMarca";
            this.tbMarca.Padding = new System.Windows.Forms.Padding(3);
            this.tbMarca.Size = new System.Drawing.Size(663, 477);
            this.tbMarca.TabIndex = 0;
            this.tbMarca.Text = "CONTROLE DE MARCAS";
            // 
            // bt_CM_excluir
            // 
            this.bt_CM_excluir.BackColor = System.Drawing.Color.OrangeRed;
            this.bt_CM_excluir.FlatAppearance.BorderSize = 0;
            this.bt_CM_excluir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_CM_excluir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_CM_excluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_CM_excluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_CM_excluir.ForeColor = System.Drawing.Color.White;
            this.bt_CM_excluir.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_CM_excluir.Location = new System.Drawing.Point(219, 411);
            this.bt_CM_excluir.Name = "bt_CM_excluir";
            this.bt_CM_excluir.Size = new System.Drawing.Size(71, 45);
            this.bt_CM_excluir.TabIndex = 84;
            this.bt_CM_excluir.Text = "E&XCLUIR";
            this.bt_CM_excluir.UseVisualStyleBackColor = false;
            this.bt_CM_excluir.Click += new System.EventHandler(this.bt_CM_excluir_Click);
            // 
            // P_CM_grid
            // 
            this.P_CM_grid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.P_CM_grid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.P_CM_grid.Controls.Add(this.dtg_CM);
            this.P_CM_grid.Location = new System.Drawing.Point(2, 142);
            this.P_CM_grid.Name = "P_CM_grid";
            this.P_CM_grid.Size = new System.Drawing.Size(660, 248);
            this.P_CM_grid.TabIndex = 47;
            // 
            // dtg_CM
            // 
            this.dtg_CM.AllowUserToResizeColumns = false;
            this.dtg_CM.AllowUserToResizeRows = false;
            this.dtg_CM.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtg_CM.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dtg_CM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_CM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCMid,
            this.colCMdesc,
            this.colCativo});
            this.dtg_CM.Location = new System.Drawing.Point(19, 16);
            this.dtg_CM.MultiSelect = false;
            this.dtg_CM.Name = "dtg_CM";
            this.dtg_CM.ReadOnly = true;
            this.dtg_CM.Size = new System.Drawing.Size(620, 214);
            this.dtg_CM.TabIndex = 46;
            this.dtg_CM.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Dtg_CM_CellContentClick);
            // 
            // bt_CM_cad
            // 
            this.bt_CM_cad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.bt_CM_cad.FlatAppearance.BorderSize = 0;
            this.bt_CM_cad.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_CM_cad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_CM_cad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_CM_cad.ForeColor = System.Drawing.Color.White;
            this.bt_CM_cad.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_CM_cad.Location = new System.Drawing.Point(498, 411);
            this.bt_CM_cad.Name = "bt_CM_cad";
            this.bt_CM_cad.Size = new System.Drawing.Size(144, 45);
            this.bt_CM_cad.TabIndex = 83;
            this.bt_CM_cad.Text = "&CADASTRAR";
            this.bt_CM_cad.UseVisualStyleBackColor = false;
            this.bt_CM_cad.Click += new System.EventHandler(this.bt_CM_cad_Click);
            // 
            // bt_CM_limpar
            // 
            this.bt_CM_limpar.BackColor = System.Drawing.Color.Orange;
            this.bt_CM_limpar.FlatAppearance.BorderSize = 0;
            this.bt_CM_limpar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_CM_limpar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_CM_limpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_CM_limpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_CM_limpar.ForeColor = System.Drawing.Color.White;
            this.bt_CM_limpar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_CM_limpar.Location = new System.Drawing.Point(157, 411);
            this.bt_CM_limpar.Name = "bt_CM_limpar";
            this.bt_CM_limpar.Size = new System.Drawing.Size(56, 45);
            this.bt_CM_limpar.TabIndex = 80;
            this.bt_CM_limpar.Text = "L&IMPAR";
            this.bt_CM_limpar.UseVisualStyleBackColor = false;
            this.bt_CM_limpar.Click += new System.EventHandler(this.bt_CM_limpar_Click);
            // 
            // P_CM
            // 
            this.P_CM.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.P_CM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.P_CM.Controls.Add(this.label6);
            this.P_CM.Controls.Add(this.label7);
            this.P_CM.Controls.Add(this.cbx_CM_ativo);
            this.P_CM.Controls.Add(this.tb_CM_cod);
            this.P_CM.Controls.Add(this.lbl_CM_codmar);
            this.P_CM.Controls.Add(this.tb_CM_desc);
            this.P_CM.Controls.Add(this.lbl_CM_desc);
            this.P_CM.Location = new System.Drawing.Point(2, 0);
            this.P_CM.Name = "P_CM";
            this.P_CM.Size = new System.Drawing.Size(660, 144);
            this.P_CM.TabIndex = 34;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(46, 105);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 9);
            this.label6.TabIndex = 58;
            this.label6.Text = "Marca de veiculo ATIVO";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(94, 118);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 9);
            this.label7.TabIndex = 59;
            this.label7.Text = "ou NÃO ativo";
            // 
            // cbx_CM_ativo
            // 
            this.cbx_CM_ativo.AutoCompleteCustomSource.AddRange(new string[] {
            "ATIVO"});
            this.cbx_CM_ativo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_CM_ativo.ForeColor = System.Drawing.Color.OrangeRed;
            this.cbx_CM_ativo.FormattingEnabled = true;
            this.cbx_CM_ativo.Items.AddRange(new object[] {
            "ATIVO",
            "NÃO ativo"});
            this.cbx_CM_ativo.Location = new System.Drawing.Point(166, 106);
            this.cbx_CM_ativo.Name = "cbx_CM_ativo";
            this.cbx_CM_ativo.Size = new System.Drawing.Size(121, 21);
            this.cbx_CM_ativo.TabIndex = 57;
            // 
            // tb_CM_cod
            // 
            this.tb_CM_cod.BackColor = System.Drawing.Color.White;
            this.tb_CM_cod.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_CM_cod.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tb_CM_cod.ForeColor = System.Drawing.Color.Turquoise;
            this.tb_CM_cod.Location = new System.Drawing.Point(128, 31);
            this.tb_CM_cod.Name = "tb_CM_cod";
            this.tb_CM_cod.Size = new System.Drawing.Size(151, 29);
            this.tb_CM_cod.TabIndex = 32;
            // 
            // lbl_CM_codmar
            // 
            this.lbl_CM_codmar.AutoSize = true;
            this.lbl_CM_codmar.Location = new System.Drawing.Point(38, 39);
            this.lbl_CM_codmar.Name = "lbl_CM_codmar";
            this.lbl_CM_codmar.Size = new System.Drawing.Size(65, 13);
            this.lbl_CM_codmar.TabIndex = 29;
            this.lbl_CM_codmar.Text = "Cód. Marca:";
            // 
            // tb_CM_desc
            // 
            this.tb_CM_desc.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tb_CM_desc.Location = new System.Drawing.Point(128, 65);
            this.tb_CM_desc.Name = "tb_CM_desc";
            this.tb_CM_desc.Size = new System.Drawing.Size(493, 29);
            this.tb_CM_desc.TabIndex = 2;
            // 
            // lbl_CM_desc
            // 
            this.lbl_CM_desc.AutoSize = true;
            this.lbl_CM_desc.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_CM_desc.Location = new System.Drawing.Point(38, 70);
            this.lbl_CM_desc.Name = "lbl_CM_desc";
            this.lbl_CM_desc.Size = new System.Drawing.Size(58, 13);
            this.lbl_CM_desc.TabIndex = 3;
            this.lbl_CM_desc.Text = "Descrição:";
            this.lbl_CM_desc.Click += new System.EventHandler(this.lbl_descmar_Click);
            // 
            // bt_CM_alterar
            // 
            this.bt_CM_alterar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(98)))), ((int)(((byte)(97)))));
            this.bt_CM_alterar.FlatAppearance.BorderSize = 0;
            this.bt_CM_alterar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_CM_alterar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_CM_alterar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_CM_alterar.ForeColor = System.Drawing.Color.White;
            this.bt_CM_alterar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_CM_alterar.Location = new System.Drawing.Point(397, 411);
            this.bt_CM_alterar.Name = "bt_CM_alterar";
            this.bt_CM_alterar.Size = new System.Drawing.Size(94, 45);
            this.bt_CM_alterar.TabIndex = 82;
            this.bt_CM_alterar.Text = "&ALTERAR";
            this.bt_CM_alterar.UseVisualStyleBackColor = false;
            this.bt_CM_alterar.Click += new System.EventHandler(this.bt_CM_alterar_Click);
            // 
            // lbl_CM_marcas
            // 
            this.lbl_CM_marcas.AutoSize = true;
            this.lbl_CM_marcas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_CM_marcas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CM_marcas.Location = new System.Drawing.Point(61, 434);
            this.lbl_CM_marcas.Name = "lbl_CM_marcas";
            this.lbl_CM_marcas.Size = new System.Drawing.Size(86, 22);
            this.lbl_CM_marcas.TabIndex = 79;
            this.lbl_CM_marcas.Text = "MARCAS";
            this.lbl_CM_marcas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_CM_controlede
            // 
            this.lbl_CM_controlede.AutoSize = true;
            this.lbl_CM_controlede.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_CM_controlede.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CM_controlede.Location = new System.Drawing.Point(22, 413);
            this.lbl_CM_controlede.Name = "lbl_CM_controlede";
            this.lbl_CM_controlede.Size = new System.Drawing.Size(125, 22);
            this.lbl_CM_controlede.TabIndex = 78;
            this.lbl_CM_controlede.Text = "CONTROLE DE";
            this.lbl_CM_controlede.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bt_CM_listar
            // 
            this.bt_CM_listar.BackColor = System.Drawing.Color.CadetBlue;
            this.bt_CM_listar.FlatAppearance.BorderSize = 0;
            this.bt_CM_listar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_CM_listar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_CM_listar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_CM_listar.ForeColor = System.Drawing.Color.White;
            this.bt_CM_listar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_CM_listar.Location = new System.Drawing.Point(296, 411);
            this.bt_CM_listar.Name = "bt_CM_listar";
            this.bt_CM_listar.Size = new System.Drawing.Size(94, 45);
            this.bt_CM_listar.TabIndex = 81;
            this.bt_CM_listar.Text = "&LISTAR";
            this.bt_CM_listar.UseVisualStyleBackColor = false;
            this.bt_CM_listar.Click += new System.EventHandler(this.bt_CM_listar_Click);
            // 
            // tbModelo
            // 
            this.tbModelo.BackColor = System.Drawing.Color.White;
            this.tbModelo.Controls.Add(this.bt_M_excluir);
            this.tbModelo.Controls.Add(this.bt_M_cadastrar);
            this.tbModelo.Controls.Add(this.bt_M_limpar);
            this.tbModelo.Controls.Add(this.bt_M_alterar);
            this.tbModelo.Controls.Add(this.label3);
            this.tbModelo.Controls.Add(this.bt_M_Listar);
            this.tbModelo.Controls.Add(this.label8);
            this.tbModelo.Controls.Add(this.panel7);
            this.tbModelo.Controls.Add(this.panel4);
            this.tbModelo.Location = new System.Drawing.Point(4, 4);
            this.tbModelo.Name = "tbModelo";
            this.tbModelo.Padding = new System.Windows.Forms.Padding(3);
            this.tbModelo.Size = new System.Drawing.Size(663, 477);
            this.tbModelo.TabIndex = 1;
            this.tbModelo.Text = "CONTROLE DE MODELOS";
            // 
            // bt_M_excluir
            // 
            this.bt_M_excluir.BackColor = System.Drawing.Color.OrangeRed;
            this.bt_M_excluir.FlatAppearance.BorderSize = 0;
            this.bt_M_excluir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_M_excluir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_M_excluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_M_excluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_M_excluir.ForeColor = System.Drawing.Color.White;
            this.bt_M_excluir.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_M_excluir.Location = new System.Drawing.Point(219, 411);
            this.bt_M_excluir.Name = "bt_M_excluir";
            this.bt_M_excluir.Size = new System.Drawing.Size(71, 45);
            this.bt_M_excluir.TabIndex = 84;
            this.bt_M_excluir.Text = "E&XCLUIR";
            this.bt_M_excluir.UseVisualStyleBackColor = false;
            this.bt_M_excluir.Click += new System.EventHandler(this.bt_M_excluir_Click);
            // 
            // bt_M_cadastrar
            // 
            this.bt_M_cadastrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.bt_M_cadastrar.FlatAppearance.BorderSize = 0;
            this.bt_M_cadastrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_M_cadastrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_M_cadastrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_M_cadastrar.ForeColor = System.Drawing.Color.White;
            this.bt_M_cadastrar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_M_cadastrar.Location = new System.Drawing.Point(498, 411);
            this.bt_M_cadastrar.Name = "bt_M_cadastrar";
            this.bt_M_cadastrar.Size = new System.Drawing.Size(144, 45);
            this.bt_M_cadastrar.TabIndex = 83;
            this.bt_M_cadastrar.Text = "&CADASTRAR";
            this.bt_M_cadastrar.UseVisualStyleBackColor = false;
            this.bt_M_cadastrar.Click += new System.EventHandler(this.bt_M_cadastrar_Click);
            // 
            // bt_M_limpar
            // 
            this.bt_M_limpar.BackColor = System.Drawing.Color.Orange;
            this.bt_M_limpar.FlatAppearance.BorderSize = 0;
            this.bt_M_limpar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_M_limpar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_M_limpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_M_limpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_M_limpar.ForeColor = System.Drawing.Color.White;
            this.bt_M_limpar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_M_limpar.Location = new System.Drawing.Point(157, 411);
            this.bt_M_limpar.Name = "bt_M_limpar";
            this.bt_M_limpar.Size = new System.Drawing.Size(56, 45);
            this.bt_M_limpar.TabIndex = 80;
            this.bt_M_limpar.Text = "L&IMPAR";
            this.bt_M_limpar.UseVisualStyleBackColor = false;
            this.bt_M_limpar.Click += new System.EventHandler(this.button3_Click);
            // 
            // bt_M_alterar
            // 
            this.bt_M_alterar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(98)))), ((int)(((byte)(97)))));
            this.bt_M_alterar.FlatAppearance.BorderSize = 0;
            this.bt_M_alterar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_M_alterar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_M_alterar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_M_alterar.ForeColor = System.Drawing.Color.White;
            this.bt_M_alterar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_M_alterar.Location = new System.Drawing.Point(397, 411);
            this.bt_M_alterar.Name = "bt_M_alterar";
            this.bt_M_alterar.Size = new System.Drawing.Size(94, 45);
            this.bt_M_alterar.TabIndex = 82;
            this.bt_M_alterar.Text = "&ALTERAR";
            this.bt_M_alterar.UseVisualStyleBackColor = false;
            this.bt_M_alterar.Click += new System.EventHandler(this.bt_M_alterar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 413);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 22);
            this.label3.TabIndex = 78;
            this.label3.Text = "CONTROLE DE";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bt_M_Listar
            // 
            this.bt_M_Listar.BackColor = System.Drawing.Color.CadetBlue;
            this.bt_M_Listar.FlatAppearance.BorderSize = 0;
            this.bt_M_Listar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_M_Listar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_M_Listar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_M_Listar.ForeColor = System.Drawing.Color.White;
            this.bt_M_Listar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_M_Listar.Location = new System.Drawing.Point(296, 411);
            this.bt_M_Listar.Name = "bt_M_Listar";
            this.bt_M_Listar.Size = new System.Drawing.Size(94, 45);
            this.bt_M_Listar.TabIndex = 81;
            this.bt_M_Listar.Text = "&LISTAR";
            this.bt_M_Listar.UseVisualStyleBackColor = false;
            this.bt_M_Listar.Click += new System.EventHandler(this.bt_M_Listar_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(49, 434);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 22);
            this.label8.TabIndex = 79;
            this.label8.Text = "MODELOS";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.dtg_Mod);
            this.panel7.Location = new System.Drawing.Point(2, 166);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(660, 224);
            this.panel7.TabIndex = 36;
            // 
            // dtg_Mod
            // 
            this.dtg_Mod.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_Mod.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMDcod,
            this.colMDmar,
            this.colMDdesc,
            this.colMDativo});
            this.dtg_Mod.Location = new System.Drawing.Point(19, 14);
            this.dtg_Mod.Name = "dtg_Mod";
            this.dtg_Mod.ReadOnly = true;
            this.dtg_Mod.Size = new System.Drawing.Size(620, 192);
            this.dtg_Mod.TabIndex = 48;
            this.dtg_Mod.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Dtg_Mod_CellContentClick);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.cbx_M_apto);
            this.panel4.Controls.Add(this.tb_M_marca);
            this.panel4.Controls.Add(this.lbl_MD_cmarcas);
            this.panel4.Controls.Add(this.tb_M_cod);
            this.panel4.Controls.Add(this.lbl_MD_cod);
            this.panel4.Controls.Add(this.tb_M_desc);
            this.panel4.Controls.Add(this.lbl_MD_descricao);
            this.panel4.Location = new System.Drawing.Point(2, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(660, 168);
            this.panel4.TabIndex = 35;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(80, 129);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(114, 9);
            this.label12.TabIndex = 55;
            this.label12.Text = "Modelo de veiculo ATIVO";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(132, 142);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 9);
            this.label13.TabIndex = 56;
            this.label13.Text = "ou NÃO ativo";
            // 
            // cbx_M_apto
            // 
            this.cbx_M_apto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_M_apto.ForeColor = System.Drawing.Color.OrangeRed;
            this.cbx_M_apto.FormattingEnabled = true;
            this.cbx_M_apto.Items.AddRange(new object[] {
            "ATIVO",
            "NÃO ativo"});
            this.cbx_M_apto.Location = new System.Drawing.Point(200, 130);
            this.cbx_M_apto.Name = "cbx_M_apto";
            this.cbx_M_apto.Size = new System.Drawing.Size(121, 21);
            this.cbx_M_apto.TabIndex = 54;
            // 
            // tb_M_marca
            // 
            this.tb_M_marca.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tb_M_marca.ForeColor = System.Drawing.Color.Maroon;
            this.tb_M_marca.Location = new System.Drawing.Point(128, 50);
            this.tb_M_marca.Name = "tb_M_marca";
            this.tb_M_marca.Size = new System.Drawing.Size(151, 29);
            this.tb_M_marca.TabIndex = 39;
            // 
            // lbl_MD_cmarcas
            // 
            this.lbl_MD_cmarcas.AutoSize = true;
            this.lbl_MD_cmarcas.Location = new System.Drawing.Point(38, 58);
            this.lbl_MD_cmarcas.Name = "lbl_MD_cmarcas";
            this.lbl_MD_cmarcas.Size = new System.Drawing.Size(91, 13);
            this.lbl_MD_cmarcas.TabIndex = 38;
            this.lbl_MD_cmarcas.Text = "Código da Marca:";
            // 
            // tb_M_cod
            // 
            this.tb_M_cod.BackColor = System.Drawing.Color.White;
            this.tb_M_cod.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_M_cod.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tb_M_cod.ForeColor = System.Drawing.Color.Turquoise;
            this.tb_M_cod.Location = new System.Drawing.Point(128, 16);
            this.tb_M_cod.Name = "tb_M_cod";
            this.tb_M_cod.Size = new System.Drawing.Size(82, 29);
            this.tb_M_cod.TabIndex = 32;
            this.tb_M_cod.Enter += new System.EventHandler(this.bt_M_Listar_Click);
            // 
            // lbl_MD_cod
            // 
            this.lbl_MD_cod.AutoSize = true;
            this.lbl_MD_cod.Location = new System.Drawing.Point(38, 24);
            this.lbl_MD_cod.Name = "lbl_MD_cod";
            this.lbl_MD_cod.Size = new System.Drawing.Size(70, 13);
            this.lbl_MD_cod.TabIndex = 29;
            this.lbl_MD_cod.Text = "Cód. Modelo:";
            // 
            // tb_M_desc
            // 
            this.tb_M_desc.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tb_M_desc.Location = new System.Drawing.Point(128, 84);
            this.tb_M_desc.Name = "tb_M_desc";
            this.tb_M_desc.Size = new System.Drawing.Size(493, 29);
            this.tb_M_desc.TabIndex = 2;
            // 
            // lbl_MD_descricao
            // 
            this.lbl_MD_descricao.AutoSize = true;
            this.lbl_MD_descricao.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_MD_descricao.Location = new System.Drawing.Point(38, 92);
            this.lbl_MD_descricao.Name = "lbl_MD_descricao";
            this.lbl_MD_descricao.Size = new System.Drawing.Size(58, 13);
            this.lbl_MD_descricao.TabIndex = 3;
            this.lbl_MD_descricao.Text = "Descrição:";
            // 
            // colVcod
            // 
            this.colVcod.HeaderText = "Cód . Veículo";
            this.colVcod.Name = "colVcod";
            this.colVcod.ReadOnly = true;
            this.colVcod.Width = 90;
            // 
            // colVdesc
            // 
            this.colVdesc.HeaderText = "Descrição do Veículo";
            this.colVdesc.Name = "colVdesc";
            this.colVdesc.ReadOnly = true;
            this.colVdesc.Width = 250;
            // 
            // colVmod
            // 
            this.colVmod.HeaderText = "Cód. Modelo";
            this.colVmod.Name = "colVmod";
            this.colVmod.ReadOnly = true;
            this.colVmod.Width = 90;
            // 
            // colVano
            // 
            this.colVano.HeaderText = "Ano";
            this.colVano.Name = "colVano";
            this.colVano.ReadOnly = true;
            this.colVano.Width = 50;
            // 
            // colVcor
            // 
            this.colVcor.HeaderText = "Cor";
            this.colVcor.Name = "colVcor";
            this.colVcor.ReadOnly = true;
            this.colVcor.Width = 97;
            // 
            // colVobs
            // 
            this.colVobs.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colVobs.HeaderText = "obs";
            this.colVobs.Name = "colVobs";
            this.colVobs.ReadOnly = true;
            this.colVobs.Visible = false;
            // 
            // colVapto
            // 
            this.colVapto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colVapto.HeaderText = "apto";
            this.colVapto.Name = "colVapto";
            this.colVapto.ReadOnly = true;
            this.colVapto.Visible = false;
            // 
            // colMDcod
            // 
            this.colMDcod.HeaderText = "Cód. Modelo";
            this.colMDcod.Name = "colMDcod";
            this.colMDcod.ReadOnly = true;
            this.colMDcod.Width = 80;
            // 
            // colMDmar
            // 
            this.colMDmar.HeaderText = "Cód Marca";
            this.colMDmar.Name = "colMDmar";
            this.colMDmar.ReadOnly = true;
            this.colMDmar.Width = 80;
            // 
            // colMDdesc
            // 
            this.colMDdesc.HeaderText = "Descrição do Modelo";
            this.colMDdesc.Name = "colMDdesc";
            this.colMDdesc.ReadOnly = true;
            this.colMDdesc.Width = 415;
            // 
            // colMDativo
            // 
            this.colMDativo.HeaderText = "ativo";
            this.colMDativo.Name = "colMDativo";
            this.colMDativo.ReadOnly = true;
            this.colMDativo.Visible = false;
            // 
            // colCMid
            // 
            this.colCMid.HeaderText = "Cód. Marca";
            this.colCMid.Name = "colCMid";
            this.colCMid.ReadOnly = true;
            // 
            // colCMdesc
            // 
            this.colCMdesc.HeaderText = "Descrição da Marca";
            this.colCMdesc.Name = "colCMdesc";
            this.colCMdesc.ReadOnly = true;
            this.colCMdesc.Width = 475;
            // 
            // colCativo
            // 
            this.colCativo.HeaderText = "ATIVO";
            this.colCativo.Name = "colCativo";
            this.colCativo.ReadOnly = true;
            this.colCativo.Visible = false;
            // 
            // F_carros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 565);
            this.Controls.Add(this.P_Carros);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "F_carros";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormControlVeic";
            this.Load += new System.EventHandler(this.F_carros_Load);
            this.P_Carros.ResumeLayout(false);
            this.P_Carros.PerformLayout();
            this.tb_Veiculos.ResumeLayout(false);
            this.tbVeiculos.ResumeLayout(false);
            this.tbVeiculos.PerformLayout();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_V)).EndInit();
            this.P_veiculo.ResumeLayout(false);
            this.P_veiculo.PerformLayout();
            this.tbMarca.ResumeLayout(false);
            this.tbMarca.PerformLayout();
            this.P_CM_grid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_CM)).EndInit();
            this.P_CM.ResumeLayout(false);
            this.P_CM.PerformLayout();
            this.tbModelo.ResumeLayout(false);
            this.tbModelo.PerformLayout();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Mod)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel P_Carros;
        private System.Windows.Forms.Button bt_Sair;
        private System.Windows.Forms.Label lb_Veiculos;
        private System.Windows.Forms.TabControl tb_Veiculos;
        private System.Windows.Forms.Button btExcluir;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.DataGridView dtg_V;
        private System.Windows.Forms.Button bt_C_cad;
        private System.Windows.Forms.Button bt_V_limpa;
        private System.Windows.Forms.Panel P_veiculo;
        private System.Windows.Forms.TextBox tb_V_obs;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cb_V_cor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_V_ano;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_V_codmod;
        private System.Windows.Forms.Label lbl_V_codmod;
        private System.Windows.Forms.TextBox tb_V_cod;
        private System.Windows.Forms.Label lbl_V_cod;
        private System.Windows.Forms.TextBox tb_V_desc;
        private System.Windows.Forms.Label lbl_V_desc;
        private System.Windows.Forms.Button bt_C_altera;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button bt_C_lista;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tbMarca;
        private System.Windows.Forms.Button bt_CM_excluir;
        private System.Windows.Forms.Panel P_CM_grid;
        private System.Windows.Forms.DataGridView dtg_CM;
        private System.Windows.Forms.Button bt_CM_cad;
        private System.Windows.Forms.Button bt_CM_limpar;
        private System.Windows.Forms.Panel P_CM;
        private System.Windows.Forms.TextBox tb_CM_cod;
        private System.Windows.Forms.Label lbl_CM_codmar;
        private System.Windows.Forms.TextBox tb_CM_desc;
        private System.Windows.Forms.Label lbl_CM_desc;
        private System.Windows.Forms.Button bt_CM_alterar;
        private System.Windows.Forms.Label lbl_CM_marcas;
        private System.Windows.Forms.Label lbl_CM_controlede;
        private System.Windows.Forms.Button bt_CM_listar;
        private System.Windows.Forms.TabPage tbModelo;
        private System.Windows.Forms.Button bt_M_excluir;
        private System.Windows.Forms.Button bt_M_cadastrar;
        private System.Windows.Forms.Button bt_M_limpar;
        private System.Windows.Forms.Button bt_M_alterar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bt_M_Listar;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DataGridView dtg_Mod;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox tb_M_marca;
        private System.Windows.Forms.Label lbl_MD_cmarcas;
        private System.Windows.Forms.TextBox tb_M_cod;
        private System.Windows.Forms.Label lbl_MD_cod;
        private System.Windows.Forms.TextBox tb_M_desc;
        private System.Windows.Forms.Label lbl_MD_descricao;
        private System.Windows.Forms.TabPage tbVeiculos;
        private System.Windows.Forms.ComboBox car_apto;
        private System.Windows.Forms.ComboBox cbx_M_apto;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbx_CM_ativo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVcod;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVdesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVmod;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVano;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVcor;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVobs;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVapto;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMDcod;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMDmar;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMDdesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMDativo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCMid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCMdesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCativo;
    }
}