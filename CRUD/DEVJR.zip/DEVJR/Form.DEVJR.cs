﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DEVJR
{
    public partial class F_DevJr : Form
    {
        public F_DevJr()
        {
            InitializeComponent();
        }

        private MySqlConnectionStringBuilder ConexaoBanco()
        {
            MySqlConnectionStringBuilder conexaoBD = new MySqlConnectionStringBuilder();
            conexaoBD.Server = "localhost";
            conexaoBD.Database = "devjr";
            conexaoBD.UserID = "root";
            conexaoBD.Password = "";
            conexaoBD.SslMode = MySql.Data.MySqlClient.MySqlSslMode.None;
            return (MySqlConnectionStringBuilder)conexaoBD;
        }

        private void CLIENTESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (P_Locar.Visible == true)
                P_Locar.Visible = false;
            else
                P_Locar.Visible = true;
        }

        private void SAIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void F_DevJr_Load(object sender, EventArgs e)
        {

        }

        private void CLIENTESToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            
        }

        private void SAIRToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            
        }

        private void Bt_CadCli_Click(object sender, EventArgs e)
        {
           
        }

        private void SAIRToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ToolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void Bt_Altera_Click(object sender, EventArgs e)
        {
            
        }

        private void Bt_Busca_Click(object sender, EventArgs e)
        {
            
        }

        private void Bt_Update_Click(object sender, EventArgs e)
        {

        }

        private void CADASTROToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void FornecedoresToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void FuncionáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void VeiculosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void LOCAÇÃOToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void VENDASToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (P_Locar.Visible == true)
                P_Locar.Visible = false;
            else
                P_Locar.Visible = true;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (P_Locar.Visible == true);
            P_Locar.Visible = false;
            F_Locacao openform = new F_Locacao();
            openform.ShowDialog();
            
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void bt_locação_Click(object sender, EventArgs e)
        {
            if (P_Locar.Visible == true)
                P_Locar.Visible = false;
            else
                P_Locar.Visible = true;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
        if (P_Locar.Visible == true) ;
              P_Locar.Visible = false;

            F_carros openform = new F_carros();
            openform.ShowDialog();
        }

        private void TB_CPF_TextChanged(object sender, EventArgs e)
        {

        }

        private void toolStripContainer1_ContentPanel_Load(object sender, EventArgs e)
        {

        }

        private void TB_CodCli_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void btSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (P_Locar.Visible == true) ;
            P_Locar.Visible = false;
        }

        private void P_CadCli_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bt_C_lista_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open();

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand();
                comandoMySql.CommandText = "SELECT * FROM locar WHERE loc_id = '" + tb_L_CodLoc.Text + "'";
                MySqlDataReader reader = comandoMySql.ExecuteReader();

                    //dgLocadora.Rows.Clear();

                while (reader.Read())
                {
                    tb_L_CodLoc.Text = reader.GetString(0);     //id locar
                    tb_L_codveic.Text = reader.GetString(1);    //cod veiculo
                    tb_L_codcli.Text = reader.GetString(2);     //cod cliente
                    dtp_L_dtaloc.Text = reader.GetString(3);    //data locacao
                    dtp_L_dtadev.Text = reader.GetString(4);    //data devolução
                    tb_L_valdia.Text = reader.GetString(5);     //valor diaria
                    //tb_L_valtot.Text = reader.GetString(6);     //valor total
                    tb_L_obs.Text = reader.GetString(6);        //observação
                    //cb_L_devolver.Text = reader.GetString(8);   //logica devoluçao                    
                }

                realizaConexacoBD.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Existem campos não preenchidos, Atualize seus dados! ");
                Console.WriteLine(ex.Message);
            }
        }

        private void bt_C_cad_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open();

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand();

                    //INSERT INTO `cliente` (`id`, `cli_cpf`, `cli_nome`, `cli_end`, `cli_bairro`, `cli_cep`, `cli_cidade`, `cli_uf`, `cli_email`, `cli_fone_w`)
                    //VALUES(NULL, 'LIMPEZA', 'SABAO EM PÓ', '5', '7', '1');

                comandoMySql.CommandText = "INSERT INTO locar (loc_codveic, loc_codcli,loc_dta_loc,loc_dta_devolve,loc_valor_dia,loc_total_diaria,loc_obs,loc_devolucao)" +
                        "VALUES('" + tb_L_codveic.Text + "', '" + tb_L_codcli.Text + "', '" + dtp_L_dtaloc.Text + "', '" + dtp_L_dtadev.Text + "', '" + tb_L_valdia.Text + "', '" + tb_L_obs.Text + "', '" + cb_L_devolver.Text + "')";
                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close();
                MessageBox.Show("Veículo Alugado com Sucesso!");
                    //AtualizaGrid();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            LimparCampos();
            
        }
        private void LimparCampos()
        {
            tb_L_CodLoc.Clear();
            tb_L_codveic.Clear();
            tb_L_codcli.Clear();         
            tb_L_valdia.Clear();
            //tb_L_valtot.Clear();
            tb_L_obs.Clear();
            cb_L_devolver.Checked = false;
                //dtp_L_dtaloc.Format = DateTimePickerFormat.Custom;
                //dtp_L_dtaloc.CustomFormat = "dd-mm-yyyy";
                //dtp_L_dtadev.Format = DateTimePickerFormat.Custom;
                //dtp_L_dtadev.CustomFormat = "dd-mm-yyyy";
        }

        private void btExcluir_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open(); //Abre a conexão com o banco

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand(); //Crio um comando SQL
                    // "DELETE FROM filme WHERE idFilme = "+ textBoxId.Text +""
                    //comandoMySql.CommandText = "DELETE FROM filme WHERE idFilme = " + tbID.Text + "";
                comandoMySql.CommandText = "DELETE from locar WHERE locar.loc_id = " + tb_L_CodLoc.Text + "";

                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close(); // Fecho a conexão com o banco
                MessageBox.Show("Deletado com sucesso"); //Exibo mensagem de aviso
                    //AtualizaGrid();
                LimparCampos();
            }
            catch (Exception ex)
            {
                    //MessageBox.Show("Não foi possivel abrir a conexão! ");
                Console.WriteLine(ex.Message);
            }
        }

        private void bt_C_altera_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open(); //Abre a conexão com o banco

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand(); //Crio um comando SQL
                //UPDATE `locar` SET `loc_codveic` = '5' WHERE `locar`.`loc_id` = 12;
                comandoMySql.CommandText = "UPDATE locar SET loc_id = '" + tb_L_CodLoc.Text + "', " +
                    "loc_codveic = '" + tb_L_codveic.Text + "', " +
                    "loc_codcli = '" + tb_L_codcli.Text + "', " +
                    "loc_dta_loc = '" + dtp_L_dtaloc.Text + "', " +
                    "loc_dta_devolve = '" + dtp_L_dtadev.Text + "', " +
                    "loc_valor_dia = '" + tb_L_valdia.Text + "', " +
                    //"loc_total_diaria = '" + tb_L_valtot.Text + "', " +
                    "loc_obs = '" + tb_L_obs.Text + "' " +
                    //"loc_devolucao = '" + cb_L_devolver.Text + "', " +
                    // "loc_dta_loc = " + Convert.ToInt16(tbdta.Text) +
                    " WHERE loc_id = " + tb_L_CodLoc.Text + "";
                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close(); // Fecho a conexão com o banco
                MessageBox.Show("Alteração realizada com sucesso"); //Exibo mensagem de aviso
                //AtualizaGrid();
                LimparCampos();
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Não foi possivel abrir a conexão! ");
                Console.WriteLine(ex.Message);
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dtp_L_dtadev_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }
    }
}
