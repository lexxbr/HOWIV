﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEVJR_rent_a_car
{
    public partial class F_Dev_Jr : Form
    {
        public F_Dev_Jr()
        {
            InitializeComponent();
        }


        private void Cadastro_Click(object sender, EventArgs e)
        {

        }

        private void CADASTROToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void TCPF_Click(object sender, EventArgs e)
        {

        }

        private void Label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }

        private void CLIENTESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (P_CadCli.Visible == true)
                P_CadCli.Visible = false;
            else
                P_CadCli.Visible = true;

        }

        private void P_CadCli_Paint(object sender, PaintEventArgs e)
        {

        }

        private void TB_CPF_TextChanged(object sender, EventArgs e)
        {

        }

        private void SAIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Bt_CadCli_Click(object sender, EventArgs e)
        {

        }
    }
}